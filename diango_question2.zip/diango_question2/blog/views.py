from django.shortcuts import render, redirect
from .forms import PostForm
from django.shortcuts import render
from .models import Post
def create_post(request):
    if request.method == "POST":
        form = PostForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("post_list")
    else:
        form = PostForm()
    return render(request, "blog/create_post.html", {"form": form})



def post_list(request):
    posts = Post.objects.all().order_by("-create_at") 
    return render(request, "blog/post_list.html", {"posts": posts})


# Create your views here.
